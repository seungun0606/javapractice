package exercise;

public class Type1 {
    public static void main(String[] args){
        int myFavoriteNumber = 7;
        double pi = 3.141592;
        boolean likeMint = true;
        char mySurnameFirstAlphabet = 'Y';
        String myName = "김승건";

        System.out.println(myFavoriteNumber);
        System.out.println(pi);
        System.out.println(likeMint);
        System.out.println(mySurnameFirstAlphabet);
        System.out.println(myName);


    }
}
