package exercise.chapter_13;

public class ImplicitCasting2 {

    public static void  main(String[] args) {
        int myInt = 10;
        double myDouble = 44.1;
        double result1 = myInt + myDouble;
        System.out.println(result1);
    }
}
