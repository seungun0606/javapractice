package exercise.chapter_13;

public class integerRange {

    public static void main(String[] args){
// Byte 범위 : -128~ 127
        //Short 범위 :
        short myShort = -3278;
        System.out.println(myShort);
    }
}

