package exercise.chapter_13;

public class FloatRange {

    public static void main(String[] args){
        float myFloat = 1344329.4545f;
        System.out.println((myFloat));
    }
}
