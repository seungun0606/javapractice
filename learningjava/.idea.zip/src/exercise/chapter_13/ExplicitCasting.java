package exercise.chapter_13;

public class ExplicitCasting {
    public static  void main(String[] args){
        float myfFloat = 5.55f;
        int myInt = (int)myfFloat;
        System.out.println(myInt);
    }
}
