package exercise.chapter_13;

public class ImplicitCasting1 {

    public static void main(String[] args){
        int myInt =5;
        long myLong = myInt;
        System.out.println(myLong);
    }
}
