package exercise;

public class Operator1 {
    public  static  void main(String[] args){
        int a = 10;
        int b = a;
        int c = b;
      //  System.out.println((c));

        int positive3 = 3;
        int netgative3 = -3;
      //  System.out.println(positive3);
       // System.out.println(netgative3);

        int num1 =  625;
        int num2 = 3;
        int result = num1 / num2;
        int result2 = num1 % num2;
        System.out.println(result);
        System.out.println(result2);
    }
}
