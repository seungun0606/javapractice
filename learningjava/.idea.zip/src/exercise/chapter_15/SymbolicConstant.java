package exercise.chapter_15;

public class SymbolicConstant {
    public static void main(String[] args){
        final int MY_INT = 5;



        final  double MY_DOUBLE;
        MY_DOUBLE = 5.0;

    }
}
